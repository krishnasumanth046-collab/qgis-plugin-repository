def initGui(self):
    # Add plugin action to menu and toolbar with an icon
    self.action = QAction(QIcon(":/plugins/RoadNameStandardizer/icon.png"), "Standardize Road Names", self.iface.mainWindow())
    self.action.triggered.connect(self.run)
    self.iface.addToolBarIcon(self.action)
    self.iface.addPluginToMenu("Road Name Tools", self.action)
def classFactory(iface):
    from .RoadNameStandardizer import RoadNameStandardizer
    return RoadNameStandardizer(iface)
