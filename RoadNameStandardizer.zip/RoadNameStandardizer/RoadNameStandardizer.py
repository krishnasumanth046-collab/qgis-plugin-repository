from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QIcon  # Import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox
from qgis.core import (
    QgsProject,
    QgsSpatialIndex,
    QgsField
)
from qgis.utils import iface
import re

class RoadNameStandardizer:
    def __init__(self, iface):
        self.iface = iface
        self.action = None

    def initGui(self):
        # Add plugin action to menu and toolbar with an icon
        self.action = QAction(QIcon(":/plugins/RoadNameStandardizer/icon.png"), "Standardize Road Names", self.iface.mainWindow())  # Set icon here
        self.action.triggered.connect(self.run)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("Road Name Tools", self.action)

    def unload(self):
        # Remove plugin action from menu and toolbar
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("Road Name Tools", self.action)

    def run(self):
        try:
            self.assign_labels_and_standardize()
            QMessageBox.information(self.iface.mainWindow(), "Success", "Road names standardized successfully.")
        except Exception as e:
            QMessageBox.critical(self.iface.mainWindow(), "Error", f"An error occurred: {str(e)}")

    def assign_labels_and_standardize(self):
        # Load layers
        road_layers = QgsProject.instance().mapLayersByName("Road Centerlines")
        label_layers = QgsProject.instance().mapLayersByName("labels")

        if not road_layers:
            raise Exception("'Road Centerlines' layer not found.")
        if not label_layers:
            raise Exception("'labels' layer not found.")

        road_layer = road_layers[0]
        label_layer = label_layers[0]

        if not road_layer.isEditable():
            if not road_layer.startEditing():
                raise Exception("Cannot edit 'Road Centerlines' layer.")

        field_names = [f.name() for f in road_layer.fields()]
        new_fields = []
        if "road_name" not in field_names:
            new_fields.append(QgsField("road_name", QVariant.String))
        if "prefix" not in field_names:
            new_fields.append(QgsField("prefix", QVariant.String))
        if "suffix" not in field_names:
            new_fields.append(QgsField("suffix", QVariant.String))
        if "fullname" not in field_names:
            new_fields.append(QgsField("fullname", QVariant.String))
        if "type" not in field_names:
            new_fields.append(QgsField("type", QVariant.String))
        if new_fields:
            road_layer.dataProvider().addAttributes(new_fields)
            road_layer.updateFields()

        label_index = QgsSpatialIndex(label_layer.getFeatures())
        label_features = {f.id(): f for f in label_layer.getFeatures()}

        suffix_lookup = {
            "ST": "STREET", "AVE": "AVENUE", "RD": "ROAD", "BLVD": "BOULEVARD",
            "LN": "LANE", "DR": "DRIVE", "CT": "COURT", "PL": "PLACE", "HWY": "HIGHWAY"
        }

        prefix_pattern = re.compile(r"^(N|S|E|W|NE|NW|SE|SW)\b", re.IGNORECASE)

        for road_feat in road_layer.getFeatures():
            geom = road_feat.geometry()
            nearby_ids = label_index.intersects(geom.buffer(5, 5).boundingBox())

            min_dist = float("inf")
            closest_label = None
            for lid in nearby_ids:
                label_feat = label_features[lid]
                dist = geom.distance(label_feat.geometry())
                if dist < min_dist:
                    min_dist = dist
                    closest_label = label_feat

            road_name = ""
            if closest_label:
                road_name = closest_label["label"].strip().upper()
                road_feat["road_name"] = road_name
            else:
                continue

            prefix_match = prefix_pattern.match(road_name)
            prefix = prefix_match.group(1).upper() if prefix_match else "N"

            name_wo_prefix = re.sub(rf"^{prefix}\s+", "", road_name, flags=re.IGNORECASE)
            suffix_abbr = name_wo_prefix.split()[-1]
            suffix_full = suffix_lookup.get(suffix_abbr.upper(), suffix_abbr)
            name_wo_suffix = re.sub(rf"\s+{suffix_abbr}$", "", name_wo_prefix, flags=re.IGNORECASE)
            fullname = f"{name_wo_suffix} {suffix_full}".strip()

            road_feat["prefix"] = prefix
            road_feat["suffix"] = suffix_full
            road_feat["fullname"] = fullname
            road_feat["type"] = "RESIDENTIAL ROAD"

            road_layer.updateFeature(road_feat)

        road_layer.commitChanges()
